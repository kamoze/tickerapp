<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  * {
    box-sizing: border-box;
}

  #myBtn1{
    float: right;
  }
  #btn2{
    float: right;
  }

  .column {
    float: left;
    width: 20%;
   
}
.row::after {
    content: "";
    clear: both;
    display: table;
}

      .ul{
        width: 100%
      }
      .three{
       float: left;
      }
      .one{
        float: 
      }
      .nav{
        overflow: hidden;
        float:right;
        }
        
      .pullright{
        float:right;
      }
      .big{

        
        align-image:center;
        float:left;
      }
      .color
      {
        background-color: lightgreen;
        text-align: justify-all;
        padding-bottom: 40px;
        padding-left: 40px;
        padding-right: 40px;
        padding-top: 40px;
        float:right;
        font-family:"Times New Roman";
        font-size: 20px;
        font-color:white;
      }
      .centre
      {
        text-align: center;
        padding-bottom: 50px;
        padding-top: 50px;
      }
      .down{
        padding-top: 50px;
        padding-bottom: 50px;
    
    font-size: 25px;  }
      .bottom{
        padding-top: 100px;
        padding-bottom: 100px
      }
      .top{
       
        text-align: center;
      }
      .carousel-inner
      {
        text-align: center;
      }
      .area
      {
        font-family:"Arial";
        text-align: justify-all;
        padding-top: 50px;
        
      }
      .button
      {
        float: right;
        padding-bottom: 50px;
      }
      
      @media screen and (max-width: 600px) {
        .modal-header, h4,.close{
      background-color: powderblue;
      text-align: center;
      font-size: 30px;
  }
  .modal-footer {
      background-color: whitesmoke;
  }
  #myBtn1{
    float: right;
  }
  #btn2{
    float: right;
  }
  .navbar-inverse {
    position: relative;
    min-height: 40px;
  } 
  .navbar-inverse ul {
    width: 180px;
    padding: 5px 0;
    position: absolute;
    top: 0;
    left: 0;
    border: solid 1px #aaa;
    background: #fff url(images/icon-menu.png) no-repeat 10px 11px;
    border-radius: 5px;
    box-shadow: 0 1px 2px rgba(0,0,0,.3);
  }
  .navbar-inverse li {
    display: none; /* hide all <li> items */
    margin: 0;
  }
  .navbar-inverse.active {
    display: block; /* show only current <li> item */
  }
  .navbar-inverse a {
    display: block;
    padding: 5px 5px 5px 32px;
    text-align: left;
  }
  .navbar-inverse.active a {
    background: none;
    color: #666;
  }

  /* on nav hover */
  .navbar-inverse ul:hover {
    background-image: none;
  }
  .navbar-inverse ul:hover li {
    display: block;
    margin: 0 0 5px;
  }
  .nav.navbar-nav ul{
    text-align: center;

  }
  .navbar .navbar-nav {
  display: inline-block;
  float: none;
  vertical-align: top;
}

.navbar .navbar-collapse {
  text-align: center;
}
.overlay{
    
    position:relative;
    width:100%;
    height:100%;
    top:0px;
    left:0px;
    z-index:1000;
}
#btn2{
  align-self: center;
}
  .navbar-inverse ul:hover .active {
    
  }

  
}



 
  </style>
	</style>
<script type="text/javascript"></script></head>
<body>

        
         
          
               
               <body class="container-fluid" style="overflow-x: hidden; ">
<div class="row" style="background-color: black">
  
   <div class="container-fluid" style="background-color: black">
      <nav class="navbar navbar-default" role="navigation" style="background-color: black">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <div class="overlay">
          <a class="navbar-brand" href="#" style="font-family:ariel; font-size: 40px;"><font color="white"><b>Slick</b></font></a>
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          
        </div>
        </div>

  
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li><a href="#" font color="white">Home</a></li>
            <li><a href="#"font color="white">Listing</a></li>
            <li><a href="productpage.php" font color="white">Products</a></li>
          <li><a href="#" font color="white">contact</a></li>
            <li><a href="#" font color="white">Team</a></li>
            <li><a href="#Login" class="btn btn-default btn-sm" id="myBtn1">Login</a>
 
 
  
 
  


           </li>
           <li><a href="RegistrationPage.html" id= "btn2" class="btn btn-default btn-sm">Registration</a>
  </li>
          </ul>

      </nav>
      
   </div>
  <!--JAVASCRIPT-->
   <script src="js/jquery-1.10.2.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
</body>
</html>