<span class="red">
    <strong>{{ $slot }}</strong>
</span>