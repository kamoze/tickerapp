<div class="alert-box ss-{{ $type }} hideit">
    <p>{{ $slot }}</p>
    <i class="fa fa-times close"></i>
</div>