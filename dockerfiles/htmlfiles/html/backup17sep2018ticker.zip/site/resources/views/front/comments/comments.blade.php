@foreach($comments as $comment)
    @include('front/comments/comments-base')
@endforeach