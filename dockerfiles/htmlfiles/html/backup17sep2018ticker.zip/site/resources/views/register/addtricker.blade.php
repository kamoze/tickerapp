<!DOCTYPE html>
<html>
<head>
	<title></title>
<script type="text/javascript"></script></head>

<body>
	<div class="form control">
<form method="post" >
	<input type="text" name="name"  id="name" placeholder="Enter name">
	<input type="button" name="submit" value="submit">
</form>
</div>
</body>
</html>