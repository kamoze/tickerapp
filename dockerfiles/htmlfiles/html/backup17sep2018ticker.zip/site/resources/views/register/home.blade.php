
        
         
          
               
               name:<input type = "text" name = "name"> 

	
           </br>
            
  
               username<input type = "text" name = "username" >
               </br>
            
               password:<input type = "text" name = "password" >
               </br>
            
            
                  <input type = "submit" value = "submit">
               
      
      </form>
</body>
</html>