<!--   Core JS Files   -->
<script src="companyRegister/js/core/jquery.min.js" ></script>
<script src="companyRegister/js/core/popper.min.js" ></script>


<script src="companyRegister/js/core/bootstrap.min.js" ></script>


<script src="companyRegister/js/plugins/perfect-scrollbar.jquery.min.js" ></script>

<script src="companyRegister/js/plugins/moment.min.js"></script>



<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="companyRegister/js/plugins/bootstrap-switch.js"></script>

<!--  Plugin for Sweet Alert -->
<script src="companyRegister/js/plugins/sweetalert2.min.js"></script>

<!-- Forms Validations Plugin -->
<script src="companyRegister/js/plugins/jquery.validate.min.js"></script>

<!--  Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
<script src="companyRegister/js/plugins/jquery.bootstrap-wizard.js"></script>

<!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
<script src="companyRegister/js/plugins/bootstrap-selectpicker.js" ></script>

<!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
<script src="companyRegister/js/plugins/bootstrap-datetimepicker.js"></script>

<!--  DataTables.net Plugin, full documentation here: https://datatables.net/    -->
<script src="companyRegister/js/plugins/jquery.dataTables.min.js"></script>

<!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
<script src="companyRegister/js/plugins/bootstrap-tagsinput.js"></script>

<!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="companyRegister/s/plugins/jasny-bootstrap.min.js"></script>

<!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
<script src="companyRegister/js/plugins/fullcalendar.min.js"></script>

<!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
<script src="companyRegister/js/plugins/jquery-jvectormap.js"></script>

<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="companyRegister/js/plugins/nouislider.min.js" ></script>


<!--  Google Maps Plugin    -->

<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU"></script>

<!-- Place this tag in your head or just before your close body tag. -->
<!-- <script async defer src="../../../buttons.github.io/buttons.js"></script> -->


<!-- Chart JS -->
<script src="companyRegister/js/plugins/chartjs.min.js"></script>

<!--  Notifications Plugin    -->
<script src="companyRegister/js/plugins/bootstrap-notify.js"></script>


<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc --><script src="companyRegister/js/now-ui-dashboard.min69ea.js?v=1.1.2" type="text/javascript"></script><!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="companyRegister/demo/demo.js"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body>


</html>
