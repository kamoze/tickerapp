<?php

return [

    'error-404'     => '出错 404',
    'error-404-info'=> '这个页面不存在 !',
    'error-403'     => '出错 403',
    'error-403-info'=> '此操作未经授权 ！',
    'error-503'     => '出错 503',
    'error-503-info'=> '立刻返回 ！',

];
