<?php

return [

    'error-404' => 'Erreur 404',
    'error-404-info' => 'Cette page n\'existe pas !',
    'error-403' => 'Erreur 403',
    'error-403-info' => 'Cette action n\'est pas autorisée.',
    'error-503' => 'Erreur 503',
    'error-503-info' => 'Nous sommes bientôt de retour.',

];
