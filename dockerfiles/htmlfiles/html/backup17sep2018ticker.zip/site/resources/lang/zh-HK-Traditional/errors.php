<?php

return [

    'error-404'     => '出錯 404',
    'error-404-info'=> '這個頁面不存在 !',
    'error-403'     => '出錯 403',
    'error-403-info'=> '此操作未經授權 ！',
    'error-503'     => '出錯 503',
    'error-503-info'=> '立刻返回 ！',

];
