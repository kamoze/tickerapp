<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TickerData extends Model
{
	protected $table = 'tickers_data';
    //
}
