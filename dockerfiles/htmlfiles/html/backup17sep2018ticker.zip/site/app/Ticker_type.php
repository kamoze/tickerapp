<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticker_type extends Model
{
    //
}
