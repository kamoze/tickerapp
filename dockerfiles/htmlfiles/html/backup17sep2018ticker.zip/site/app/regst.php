<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class regst extends Model
{
    protected $fillable = [
           'id'
        ];
}
